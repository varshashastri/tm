package uk.gov.dwp.uc.pairtest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.handlers.PaymentsHandler;
import uk.gov.dwp.uc.handlers.SeatsReservationHandler;
import uk.gov.dwp.uc.handlers.ValidationHandler;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;

@Component
public class TicketServiceImpl implements TicketService {
    /**
     * Should only have private methods other than the one below.
     */
    @Autowired
    private ValidationHandler validationHandler;

    @Autowired
    private SeatsReservationHandler seatsReservationHandler;

    @Autowired
    private PaymentsHandler paymentsHandler;

    @Override
    public void purchaseTickets(Long accountId, TicketTypeRequest... ticketTypeRequests) throws InvalidPurchaseException {
        validationHandler.handle(accountId, ticketTypeRequests);
        paymentsHandler.handle(accountId, ticketTypeRequests);
        seatsReservationHandler.handle(accountId, ticketTypeRequests);
    }

}
