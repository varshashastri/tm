package uk.gov.dwp.uc.pairtest.exception;

public class AdultNotPresentException extends PurchaseRuleValidationException {
    public AdultNotPresentException(String message) {
        super(message);
    }
}
