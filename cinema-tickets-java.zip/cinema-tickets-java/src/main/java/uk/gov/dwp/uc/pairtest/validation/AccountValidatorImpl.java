package uk.gov.dwp.uc.pairtest.validation;

import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.exception.InvalidAccountException;

@Component
public class AccountValidatorImpl implements AccountValidator {
    @Override
    public void validate(final Long accountId) throws InvalidAccountException {
        if (accountId == null) {
            throw new InvalidAccountException("Account Id is missing");
        }
    }
}
