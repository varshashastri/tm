package uk.gov.dwp.uc.pairtest.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.exception.InvalidAccountException;

@Component
public class AccountValidatorImpl implements AccountValidator {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Override
    public void validate(final Long accountId) throws InvalidAccountException {
        if (accountId == null) {
            LOGGER.error("Account id is null. Please provide account id.");
            throw new InvalidAccountException("Account Id is missing");
        }
    }
}
