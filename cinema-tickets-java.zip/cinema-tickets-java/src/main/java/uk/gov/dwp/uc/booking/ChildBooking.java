package uk.gov.dwp.uc.booking;

public class ChildBooking implements PersonBooking{
    @Override
    public int getNumSeats() {
        return 1;
    }
    @Override
    public int getPrice() {
        return 15;
    }
}
