package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public class ChildBooking implements Booking {
    private static final TicketTypeRequest.Type TYPE = TicketTypeRequest.Type.CHILD;

    @Value("${child.seat}")
    private int childSeatNum;

    @Value("${child.price}")
    private int childPrice;

    @Override
    public TicketTypeRequest.Type getType() {
        return TYPE;
    }
    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return numTickets * childSeatNum;
    }
    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return childPrice * numTickets;
    }
}
