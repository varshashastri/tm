package uk.gov.dwp.uc.booking;

import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
@NoArgsConstructor
public class ChildBooking implements Booking {
    private static final TicketTypeRequest.Type TYPE = TicketTypeRequest.Type.CHILD;

    private int childSeatNum;

    private int childPrice;

    @Autowired
    public ChildBooking(@Value("${child.seat}") int childSeatNum,
                        @Value("${child.price}") int childPrice) {
        this.childPrice = childPrice;
        this.childSeatNum = childSeatNum;
    }
    @Override
    public TicketTypeRequest.Type getType() {
        return TYPE;
    }
    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return numTickets * childSeatNum;
    }
    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return childPrice * numTickets;
    }
}
