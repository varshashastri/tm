package uk.gov.dwp.uc.pairtest.validation;

import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.PurchaseRuleValidationException;

public interface PurchaseRuleValidator {
    void validate(final TicketTypeRequest[] ticketTypeRequests) throws PurchaseRuleValidationException;
}
