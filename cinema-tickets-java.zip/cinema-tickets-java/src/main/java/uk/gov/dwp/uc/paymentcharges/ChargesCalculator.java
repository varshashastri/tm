package uk.gov.dwp.uc.paymentcharges;

import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public interface ChargesCalculator {

    int calculateCharges(TicketTypeRequest[] ticketTypeRequests);
}
