package uk.gov.dwp.uc.pairtest.exception;

public class MaxTicketsExceededException extends PurchaseRuleValidationException {
    public MaxTicketsExceededException(String message) {
        super(message);
    }
}
