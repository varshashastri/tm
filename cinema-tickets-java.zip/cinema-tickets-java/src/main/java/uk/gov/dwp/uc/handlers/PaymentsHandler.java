package uk.gov.dwp.uc.handlers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import thirdparty.paymentgateway.TicketPaymentService;
import uk.gov.dwp.uc.paymentcharges.ChargesCalculator;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public class PaymentsHandler implements BaseHandler {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TicketPaymentService ticketPaymentService;
    @Autowired
    private ChargesCalculator chargesCalculator;

    public void handle(final Long accountId, final TicketTypeRequest[] ticketTypeRequests) {
        LOGGER.debug("Starting to calculate charges and make payment");
        int total = chargesCalculator.calculateCharges(ticketTypeRequests);
        ticketPaymentService.makePayment(accountId, total);
    }
}
