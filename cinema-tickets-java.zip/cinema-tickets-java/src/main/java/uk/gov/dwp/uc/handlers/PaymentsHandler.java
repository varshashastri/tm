package uk.gov.dwp.uc.handlers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import thirdparty.paymentgateway.TicketPaymentService;
import uk.gov.dwp.uc.paymentcharges.ChargesCalculator;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public class PaymentsHandler implements BaseHandler {
    @Autowired
    private TicketPaymentService ticketPaymentService;
    @Autowired
    private ChargesCalculator chargesCalculator;

    public void handle(final Long accountId, final TicketTypeRequest[] ticketTypeRequests) {
        int total = chargesCalculator.calculateCharges(ticketTypeRequests);
        ticketPaymentService.makePayment(accountId, total);
    }
}
