package uk.gov.dwp.uc.pairtest.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.AdultNotPresentException;

import java.util.Arrays;

@Component
public class AdultPresenceValidator implements PurchaseRuleValidator {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    public void validate(final TicketTypeRequest[] ticketTypeRequests) throws AdultNotPresentException{
        if(Arrays.stream(ticketTypeRequests)
                .noneMatch(ticketTypeRequest -> ticketTypeRequest.getTicketType()
                        .equals(TicketTypeRequest.Type.ADULT))){
            LOGGER.error("At least one adult should be booked in");
            throw new AdultNotPresentException("There should be at least one adult in the purchase");
        }
    }
}
