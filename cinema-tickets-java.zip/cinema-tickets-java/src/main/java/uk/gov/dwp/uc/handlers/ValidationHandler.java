package uk.gov.dwp.uc.handlers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.InvalidAccountException;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;
import uk.gov.dwp.uc.pairtest.exception.PurchaseRuleValidationException;
import uk.gov.dwp.uc.pairtest.validation.AccountValidator;
import uk.gov.dwp.uc.pairtest.validation.TicketsValidator;

@Component
public class ValidationHandler implements BaseHandler {

    @Autowired
    private TicketsValidator ticketsValidator;
    @Autowired
    private AccountValidator accountValidator;

    public void handle(final Long accountId, final TicketTypeRequest[] ticketTypeRequests) {
        try {
            accountValidator.validate(accountId);
            ticketsValidator.validate(ticketTypeRequests);
        } catch (PurchaseRuleValidationException | InvalidAccountException ex) {
            //log
            throw new InvalidPurchaseException();
        }
    }
}
