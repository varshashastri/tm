package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

import java.util.List;

@Component
public class BookingFactory {

    @Autowired
    List<Booking> bookingList;
    public Booking getBooking(TicketTypeRequest.Type type) {
        return bookingList.stream().filter(booking -> booking.getType().equals(type)).findFirst().orElseThrow(IllegalArgumentException::new);
    }
}
