package uk.gov.dwp.uc.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.booking.AdultBooking;
import uk.gov.dwp.uc.booking.InfantBooking;

@Component
public class InfantBookingProvider {
    @Bean
    InfantBooking infantBooking() {
        return new InfantBooking();
    }
}
