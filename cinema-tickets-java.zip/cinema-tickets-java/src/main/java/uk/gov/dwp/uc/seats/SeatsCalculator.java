package uk.gov.dwp.uc.seats;

import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public interface SeatsCalculator {
    int calculateNumberOfSeats(TicketTypeRequest[] ticketTypeRequests);
}
