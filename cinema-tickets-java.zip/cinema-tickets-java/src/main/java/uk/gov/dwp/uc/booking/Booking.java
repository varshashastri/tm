package uk.gov.dwp.uc.booking;

import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

public interface Booking {
    TicketTypeRequest.Type getType();
    int getTotalSeatsToBook(int numTickets);
    int getTotalPriceToPay(int numTickets);
}
