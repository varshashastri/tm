package uk.gov.dwp.uc.seats;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.booking.PersonBooking;
import uk.gov.dwp.uc.booking.PersonBookingFactory;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
@Slf4j
public class SeatsCalculatorImpl implements SeatsCalculator {

    @Autowired
    private PersonBookingFactory personBookingFactory;
    public int calculateNumberOfSeats(final TicketTypeRequest[] ticketTypeRequests) {
        int totalSeats = 0;
        for (TicketTypeRequest ticketTypeRequest : ticketTypeRequests) {
            PersonBooking personBooking = personBookingFactory.getPersonBooking(ticketTypeRequest.getTicketType());
            totalSeats += personBooking.getTotalSeatsToBook(ticketTypeRequest.getNoOfTickets());
        }
        System.out.println("seats"+ totalSeats);

        return totalSeats;
    }
}
