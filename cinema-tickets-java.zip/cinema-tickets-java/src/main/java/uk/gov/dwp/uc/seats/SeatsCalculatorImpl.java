package uk.gov.dwp.uc.seats;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.booking.Booking;
import uk.gov.dwp.uc.booking.BookingFactory;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
@Slf4j
public class SeatsCalculatorImpl implements SeatsCalculator {

    @Autowired
    private BookingFactory bookingFactory;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
    public int calculateNumberOfSeats(final TicketTypeRequest[] ticketTypeRequests) {
        int totalSeats = 0;
        for (TicketTypeRequest ticketTypeRequest : ticketTypeRequests) {
            Booking booking = bookingFactory.getBooking(ticketTypeRequest.getTicketType());
            totalSeats += booking.getTotalSeatsToBook(ticketTypeRequest.getNoOfTickets());
        }
        LOGGER.info("Seats: "+ totalSeats);

        return totalSeats;
    }
}
