package uk.gov.dwp.uc.pairtest.validation;

import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.PurchaseRuleValidationException;

public interface TicketsValidator {
    void validate(TicketTypeRequest[] ticketTypeRequests) throws PurchaseRuleValidationException;
}
