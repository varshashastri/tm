package uk.gov.dwp.uc.booking;

public interface PersonBooking {
    int getTotalSeatsToBook(int numTickets);
    int getTotalPriceToPay(int numTickets);
}
