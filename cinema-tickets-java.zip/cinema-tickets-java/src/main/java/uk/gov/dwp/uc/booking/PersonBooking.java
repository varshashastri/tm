package uk.gov.dwp.uc.booking;

public interface PersonBooking {
    int getNumSeats();
    int getPrice();
}
