package uk.gov.dwp.uc.handlers;

import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

public interface BaseHandler {
    void handle(Long accountId, TicketTypeRequest[] ticketTypeRequests);
}
