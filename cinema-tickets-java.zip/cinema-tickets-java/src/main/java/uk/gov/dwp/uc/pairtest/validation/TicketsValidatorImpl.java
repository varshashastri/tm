package uk.gov.dwp.uc.pairtest.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;
import uk.gov.dwp.uc.pairtest.exception.PurchaseRuleValidationException;

import java.util.List;

@Component
public class TicketsValidatorImpl implements TicketsValidator {
    @Autowired
    private List<PurchaseRuleValidator> purchaseRuleValidators;
    public void validate(final TicketTypeRequest[] ticketTypeRequests) throws PurchaseRuleValidationException {

        for(PurchaseRuleValidator purchaseRuleValidator: purchaseRuleValidators) {
            purchaseRuleValidator.validate(ticketTypeRequests);
        }

    }
}
