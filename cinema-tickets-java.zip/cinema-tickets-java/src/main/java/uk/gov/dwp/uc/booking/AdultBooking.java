package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AdultBooking implements PersonBooking {

    @Value("${adult.seat}")
    private int adultSeatNum;

    @Value("${adult.price}")
    private int adultPrice;
    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return adultSeatNum * numTickets;
    }

    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return adultPrice * numTickets;
    }
}
