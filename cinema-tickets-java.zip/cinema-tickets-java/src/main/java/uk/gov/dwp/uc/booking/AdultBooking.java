package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public class AdultBooking implements Booking {

    private static final TicketTypeRequest.Type TYPE = TicketTypeRequest.Type.ADULT;
    @Value("${adult.seat}")
    private int adultSeatNum;

    @Value("${adult.price}")
    private int adultPrice;
    @Override
    public TicketTypeRequest.Type getType() {
        return TYPE;
    }
    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return adultSeatNum * numTickets;
    }

    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return adultPrice * numTickets;
    }
}
