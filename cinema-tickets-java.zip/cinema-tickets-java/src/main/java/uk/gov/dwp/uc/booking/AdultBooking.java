package uk.gov.dwp.uc.booking;

import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@NoArgsConstructor
@Component
public class AdultBooking implements Booking {

    private static final TicketTypeRequest.Type TYPE = TicketTypeRequest.Type.ADULT;
    private int adultSeatNum;

    private int adultPrice;

    @Autowired
    public AdultBooking(@Value("${adult.seat}") int adultSeatNum,
                        @Value("${adult.price}") int adultPrice) {
        this.adultPrice = adultPrice;
        this.adultSeatNum = adultSeatNum;
    }

    @Override
    public TicketTypeRequest.Type getType() {
        return TYPE;
    }

    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return adultSeatNum * numTickets;
    }

    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return adultPrice * numTickets;
    }
}
