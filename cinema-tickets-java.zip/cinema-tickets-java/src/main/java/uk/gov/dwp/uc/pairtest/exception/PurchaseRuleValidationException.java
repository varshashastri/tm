package uk.gov.dwp.uc.pairtest.exception;

public class PurchaseRuleValidationException extends Exception{
    public PurchaseRuleValidationException(String message) {
        super(message);
    }
}
