package uk.gov.dwp.uc.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import thirdparty.seatbooking.SeatReservationService;
import thirdparty.seatbooking.SeatReservationServiceImpl;
import uk.gov.dwp.uc.booking.PersonBookingFactory;

@Component
public class PersonBookingFactoryProvider {
    @Bean
    PersonBookingFactory personBookingFactory() {
        return new PersonBookingFactory();
    }
}
