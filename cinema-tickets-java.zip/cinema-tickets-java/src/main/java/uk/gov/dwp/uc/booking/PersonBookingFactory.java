package uk.gov.dwp.uc.booking;

import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

public class PersonBookingFactory {
    public static PersonBooking getPersonBooking(TicketTypeRequest.Type type) {
        switch (type) {
            case ADULT:
                return new AdultBooking();
            case CHILD:
                return new ChildBooking();
            case INFANT:
                return new InfantBooking();
            default:
                throw new IllegalArgumentException("Unknown person type. It should be one of Adult, child and infant");
        }
    }
}
