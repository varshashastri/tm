package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public class PersonBookingFactory {

    @Autowired
    AdultBooking adultBooking;
    @Autowired
    ChildBooking childBooking;
    @Autowired
    InfantBooking infantBooking;
    public PersonBooking getPersonBooking(TicketTypeRequest.Type type) {
        switch (type) {
            case ADULT:
                return adultBooking;
            case CHILD:
                return childBooking;
            case INFANT:
                return infantBooking;
            default:
                throw new IllegalArgumentException("Unknown person type. It should be one of Adult, child and infant");
        }
    }
}
