package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

import java.util.List;

@Component
public class PersonBookingFactory {

    @Autowired
    List<PersonBooking> personBookingList;
    public PersonBooking getPersonBooking(TicketTypeRequest.Type type) {

        switch (type) {
            case ADULT:
                return personBookingList.stream().filter(personBooking -> personBooking instanceof AdultBooking).findAny().get();
            case CHILD:
                return personBookingList.stream().filter(personBooking -> personBooking instanceof ChildBooking).findAny().get();
            case INFANT:
                return personBookingList.stream().filter(personBooking -> personBooking instanceof InfantBooking).findAny().get();
            default:
                throw new IllegalArgumentException("Unknown person type. It should be one of Adult, child and infant");
        }
    }
}
