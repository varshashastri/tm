package uk.gov.dwp.uc.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.booking.ChildBooking;
import uk.gov.dwp.uc.booking.InfantBooking;

@Component
public class ChildBookingProvider {
    @Bean
    ChildBooking childBooking() {
        return new ChildBooking();
    }
}
