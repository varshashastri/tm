package uk.gov.dwp.uc.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import thirdparty.paymentgateway.TicketPaymentService;
import thirdparty.paymentgateway.TicketPaymentServiceImpl;
import thirdparty.seatbooking.SeatReservationService;
import thirdparty.seatbooking.SeatReservationServiceImpl;

@Component
public class TicketPaymentServiceProvider {
    @Bean
    TicketPaymentService ticketPaymentService() {
        return new TicketPaymentServiceImpl();
    }
}
