package uk.gov.dwp.uc.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import thirdparty.seatbooking.SeatReservationService;
import thirdparty.seatbooking.SeatReservationServiceImpl;

@Component
public class SeatReservationServiceProvider {
    @Bean
    SeatReservationService seatReservationService() {
        return new SeatReservationServiceImpl();
    }
}
