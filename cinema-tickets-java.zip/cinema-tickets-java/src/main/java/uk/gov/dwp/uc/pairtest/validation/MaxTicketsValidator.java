package uk.gov.dwp.uc.pairtest.validation;

import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.MaxTicketsExceededException;

public class MaxTicketsValidator implements PurchaseRuleValidator {
    public void validate(final TicketTypeRequest[] ticketTypeRequests) throws MaxTicketsExceededException {
        if (ticketTypeRequests.length > 25) {//get from application.properties
            throw new MaxTicketsExceededException("Maximum tickets allowed is 25");
        }
    }
}
