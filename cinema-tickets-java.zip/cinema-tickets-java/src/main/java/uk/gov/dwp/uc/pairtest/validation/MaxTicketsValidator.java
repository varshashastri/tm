package uk.gov.dwp.uc.pairtest.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.MaxTicketsExceededException;

public class MaxTicketsValidator implements PurchaseRuleValidator {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Value("${max.seats}")
    private int maxSeats;
    public void validate(final TicketTypeRequest[] ticketTypeRequests) throws MaxTicketsExceededException {
        if (ticketTypeRequests.length > maxSeats) {
            LOGGER.error("Please select less than 25 seats");
            throw new MaxTicketsExceededException("Maximum tickets allowed is 25");
        }
    }
}
