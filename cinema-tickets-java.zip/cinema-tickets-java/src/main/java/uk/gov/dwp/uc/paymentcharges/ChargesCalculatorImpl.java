package uk.gov.dwp.uc.paymentcharges;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.booking.PersonBooking;
import uk.gov.dwp.uc.booking.PersonBookingFactory;

import java.util.Arrays;

@Component
public class ChargesCalculatorImpl implements ChargesCalculator {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PersonBookingFactory personBookingFactory;

    public int calculateCharges(final TicketTypeRequest[] ticketTypeRequests) {
        int totalPrice = 0;

        for (final TicketTypeRequest ticketTypeRequest : ticketTypeRequests) {
            final PersonBooking personBooking = personBookingFactory.getPersonBooking(ticketTypeRequest.getTicketType());
            totalPrice += personBooking.getTotalPriceToPay(ticketTypeRequest.getNoOfTickets());
        }
        LOGGER.info("Price: " + totalPrice);
        return totalPrice;
    }
}
