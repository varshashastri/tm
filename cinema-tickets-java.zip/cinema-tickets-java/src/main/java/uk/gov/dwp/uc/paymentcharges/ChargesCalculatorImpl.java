package uk.gov.dwp.uc.paymentcharges;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.booking.Booking;
import uk.gov.dwp.uc.booking.BookingFactory;

@Component
public class ChargesCalculatorImpl implements ChargesCalculator {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private BookingFactory bookingFactory;

    public int calculateCharges(final TicketTypeRequest[] ticketTypeRequests) {
        int totalPrice = 0;

        for (final TicketTypeRequest ticketTypeRequest : ticketTypeRequests) {
            final Booking booking = bookingFactory.getBooking(ticketTypeRequest.getTicketType());
            totalPrice += booking.getTotalPriceToPay(ticketTypeRequest.getNoOfTickets());
        }
        LOGGER.info("Price: " + totalPrice);
        return totalPrice;
    }
}
