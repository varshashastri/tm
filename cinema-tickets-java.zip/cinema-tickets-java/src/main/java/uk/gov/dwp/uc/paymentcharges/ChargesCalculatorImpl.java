package uk.gov.dwp.uc.paymentcharges;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.booking.PersonBooking;
import uk.gov.dwp.uc.booking.PersonBookingFactory;

@Component
public class ChargesCalculatorImpl implements ChargesCalculator{
    @Autowired
    private PersonBookingFactory personBookingFactory;
    public int calculateCharges(final TicketTypeRequest[] ticketTypeRequests) {
        int totalPrice = 0;
        for(final TicketTypeRequest ticketTypeRequest: ticketTypeRequests) {
            final PersonBooking personBooking = personBookingFactory.getPersonBooking(ticketTypeRequest.getTicketType());
            totalPrice += personBooking.getPrice() * ticketTypeRequest.getNoOfTickets();
        }
        System.out.println(totalPrice);
        return totalPrice;
    }
}
