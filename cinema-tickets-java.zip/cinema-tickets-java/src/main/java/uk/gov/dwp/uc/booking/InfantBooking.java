package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
public class InfantBooking implements Booking {
    private static final TicketTypeRequest.Type TYPE = TicketTypeRequest.Type.INFANT;

    @Value("${infant.seat}")
    private int infantSeatNum;

    @Value("${infant.price}")
    private int infantPrice;

    @Override
    public TicketTypeRequest.Type getType() {
        return TYPE;
    }

    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return infantPrice * numTickets;
    }//wire from app.prop

    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return numTickets * infantPrice;
    }
}
