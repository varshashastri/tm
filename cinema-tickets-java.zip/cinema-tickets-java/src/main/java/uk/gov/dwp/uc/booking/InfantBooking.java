package uk.gov.dwp.uc.booking;

import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@Component
@NoArgsConstructor
public class InfantBooking implements Booking {
    private static final TicketTypeRequest.Type TYPE = TicketTypeRequest.Type.INFANT;

    private int infantSeatNum;

    private int infantPrice;
    @Autowired
    public InfantBooking(@Value("${infant.seat}") int infantSeatNum,
                        @Value("${infant.price}") int infantPrice) {
        this.infantPrice = infantPrice;
        this.infantSeatNum = infantSeatNum;
    }
    @Override
    public TicketTypeRequest.Type getType() {
        return TYPE;
    }

    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return infantPrice * numTickets;
    }

    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return numTickets * infantPrice;
    }
}
