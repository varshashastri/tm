package uk.gov.dwp.uc.booking;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class InfantBooking implements PersonBooking {
    @Value("${infant.seat}")
    private int infantSeatNum;

    @Value("${infant.price}")
    private int infantPrice;

    @Override
    public int getTotalSeatsToBook(final int numTickets) {
        return infantPrice * numTickets;
    }//wire from app.prop

    @Override
    public int getTotalPriceToPay(final int numTickets) {
        return numTickets * infantPrice;
    }
}
