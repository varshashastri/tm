package uk.gov.dwp.uc.booking;

import org.springframework.stereotype.Component;

@Component
public class InfantBooking implements PersonBooking{
    @Override
    public int getNumSeats() {
        return 0;
    }//wire from app.prop

    @Override
    public int getPrice() {
        return 0;
    }
}
