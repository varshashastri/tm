package uk.gov.dwp.uc.booking;

public class InfantBooking implements PersonBooking{
    @Override
    public int getNumSeats() {
        return 0;
    }

    @Override
    public int getPrice() {
        return 0;
    }
}
