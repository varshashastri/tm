package uk.gov.dwp.uc.pairtest.validation;

import uk.gov.dwp.uc.pairtest.exception.InvalidAccountException;

public interface AccountValidator {
    void validate(Long accountId) throws InvalidAccountException;
}
