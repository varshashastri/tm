package uk.gov.dwp.uc.handlers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import thirdparty.seatbooking.SeatReservationService;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.seats.SeatsCalculator;

@Component
public class SeatsReservationHandler implements BaseHandler {

    @Autowired
    private SeatReservationService seatReservationService;
    @Autowired
    private SeatsCalculator seatsCalculator;

    public void handle(final Long accountId, final TicketTypeRequest[] ticketTypeRequests) {
        int seats = seatsCalculator.calculateNumberOfSeats(ticketTypeRequests);
        seatReservationService.reserveSeat(accountId, seats);
    }
}
