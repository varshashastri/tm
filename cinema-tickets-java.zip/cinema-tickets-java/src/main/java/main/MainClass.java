package main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import uk.gov.dwp.uc.pairtest.TicketService;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

@SpringBootApplication
@ComponentScan(basePackages = {"uk.gov"})
public class MainClass implements CommandLineRunner {
    @Autowired
    TicketService ticketService;
    public static void main(String[] args) {
        SpringApplication.run(MainClass.class, args);
    }
    @Override
    public void run(String... args) {
        TicketTypeRequest a = new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 2);
        TicketTypeRequest c = new TicketTypeRequest(TicketTypeRequest.Type.CHILD, 1);
        TicketTypeRequest i = new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 1);

        ticketService.purchaseTickets(1L, a,c,i);
    }
}
