package thirdparty.seatbooking;

public class SeatReservationServiceImpl implements SeatReservationService {

    @Override
    public void reserveSeat(final long accountId, final int totalSeatsToAllocate) {
        // Real implementation omitted, assume working code will make the seat reservation.
    }

}
