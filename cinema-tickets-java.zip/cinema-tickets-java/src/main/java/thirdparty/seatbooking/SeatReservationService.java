package thirdparty.seatbooking;

import org.springframework.stereotype.Component;

public interface SeatReservationService {

    void reserveSeat(long accountId, int totalSeatsToAllocate);

}
