package uk.gov.dwp.uc.seats;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import uk.gov.dwp.uc.booking.*;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

import java.awt.print.Book;
import java.util.List;

import static org.mockito.Mockito.when;

@SpringBootTest
public class SeatsCalculatorTest {

    @Autowired
    @Mock
    BookingFactory bookingFactory;

    @InjectMocks
    @Autowired
    SeatsCalculatorImpl seatsCalculator;

    @Value("${adult.seat}")
    private int adultSeatNum;
    @Value("${adult.price}")
    private int adultPrice;

    @Value("${child.seat}")
    private int childSeatNum;
    @Value("${child.price}")
    private int childPrice;

    @Value("${infant.seat}")
    private int infantSeatNum;
    @Value("${infant.price}")
    private int infantPrice;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void whenAdultChildAndInfantTicketsAreBooked_RightSeatsCalculated(){
        TicketTypeRequest t1 = new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 1);
        TicketTypeRequest t2 = new TicketTypeRequest(TicketTypeRequest.Type.CHILD, 1);
        TicketTypeRequest t3 = new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 1);
        TicketTypeRequest[] ticketTypeRequests = new TicketTypeRequest[]{t1, t2, t3};
        Booking b1 = new AdultBooking(1,25);
        Booking b2 = new ChildBooking(1,15);
        Booking b3 = new InfantBooking(0,0);
        when(bookingFactory.getBooking(t1.getTicketType())).thenReturn(b1);
        when(bookingFactory.getBooking(t2.getTicketType())).thenReturn(b2);
        when(bookingFactory.getBooking(t3.getTicketType())).thenReturn(b3);
        int seats = seatsCalculator.calculateNumberOfSeats(ticketTypeRequests);
        Assertions.assertEquals(2, seats);
    }
    @Test
    public void whenInfantTicketsAreBooked_RightSeatsCalculatedAs0(){
        TicketTypeRequest t3 = new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 5);
        TicketTypeRequest[] ticketTypeRequests = new TicketTypeRequest[]{t3};
        Booking b3 = new InfantBooking(0,0);
        when(bookingFactory.getBooking(t3.getTicketType())).thenReturn(b3);
        int seats = seatsCalculator.calculateNumberOfSeats(ticketTypeRequests);
        Assertions.assertEquals(0, seats);
    }
}
