Way to run the project:
1. Put the required csv files in src/main/resources folder.
2. In the top level folder where there is pom.xml, run the following:
   sh ./start.sh src/main/resources/zone_map.csv src/main/resources/journey_data.csv src/main/resources/output.csv
3. Results should be available in src/main/resources/output.csv

Tech stack used:
Java, Spring boot for dependency injection

Assumptions:
There are 9 zones

Time spent:
4 hours

Next steps if I had more time:
1. Test the file reader classes
2. Improve exception and error handling with more logs.