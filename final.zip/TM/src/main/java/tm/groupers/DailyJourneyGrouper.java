package tm.groupers;

import org.springframework.stereotype.Component;
import tm.model.DailyJourney;

@Component
public class DailyJourneyGrouper extends TimedJourneyGrouper<DailyJourney>{

}
