package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import tm.creators.TimedJourneyCreator;
import tm.model.DailyJourney;
import tm.model.MonthlyJourney;
import tm.model.Travel;

@Component
public class MonthlyJourneyGrouper extends TimedJourneyGrouper<MonthlyJourney>{
}
