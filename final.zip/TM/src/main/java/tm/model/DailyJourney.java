package tm.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
public class DailyJourney extends AggregatedJourney implements TimedJourney, CappedJourney {
    public static final float DAILY_CAP = 15f;
    private String date;

    public String getTimePeriod() {
        return date;
    }

    public float getCap() {
        return DAILY_CAP;
    }

    @Override
    public Float calculateCharges() {
        float total = 0f;
        for (int i = 0; i < journeys.size(); ) {
            SingleTripJourney first = null;
            SingleTripJourney second = null;
            if (((SingleTripJourney) journeys.get(i)).getDirection().equals("IN")) {
                first = (SingleTripJourney) journeys.get(i);
                i++;
            }
            if (i < journeys.size() && ((SingleTripJourney) journeys.get(i)).getDirection().equals("OUT")) {
                second = (SingleTripJourney) journeys.get(i);
                i++;
            }
            total += calculateValueForJourneyPair(new ImmutablePair<>(first, second));
        }
        return applyCap(total);
    }

    private float calculateValueForJourneyPair(Pair<SingleTripJourney, SingleTripJourney> pairJourney) {
        if (pairJourney.getLeft() == null && pairJourney.getRight() == null) {
            throw new IllegalArgumentException();
        } else if (pairJourney.getLeft() == null || pairJourney.getRight() == null) {
            return 5f;
        } else {
            return 2f + pairJourney.getLeft().calculateCharges() + pairJourney.getRight().calculateCharges();
        }
    }

}
