package tm.model;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
public abstract class AggregatedJourney extends UserJourney {
     List<Journey> journeys = new ArrayList<>();

     public void addJourneys(List<? extends Journey> journeys) {
         this.journeys.addAll(journeys);
     }
     public Float calculateCharges() {
          return journeys.stream()
                  .map(Journey::calculateCharges)
                  .reduce(Float::sum)
                  .orElse(0f);
     }
}
