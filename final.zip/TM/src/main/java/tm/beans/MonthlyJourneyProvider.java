package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.TimedJourneyGrouper;
import tm.model.DailyJourney;
import tm.model.MonthlyJourney;

import java.util.List;

@Configuration
public class MonthlyJourneyProvider implements ChargeableJourneyProvider<MonthlyJourney> {
    private final List<DailyJourney> dailyJourneys;

    private final TimedJourneyGrouper<MonthlyJourney> monthlyJourneyGrouper;

    @Autowired
    public MonthlyJourneyProvider(final List<DailyJourney> dailyJourneys, final TimedJourneyGrouper<MonthlyJourney> monthlyJourneyGrouper) {
        this.dailyJourneys = dailyJourneys;
        this.monthlyJourneyGrouper = monthlyJourneyGrouper;
    }

    @Bean("monthlyJourneys")
    public List<MonthlyJourney> provideJourneys() {
        return monthlyJourneyGrouper.aggregateJourneys(dailyJourneys);
    }

}
