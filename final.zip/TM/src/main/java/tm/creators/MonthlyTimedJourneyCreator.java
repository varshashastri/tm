package tm.creators;

import org.springframework.context.annotation.Configuration;
import tm.model.Journey;
import tm.model.MonthlyJourney;
import tm.model.TimedJourney;

import java.util.List;
import java.util.Optional;

@Configuration
public class MonthlyTimedJourneyCreator extends TimedJourneyCreator<MonthlyJourney> {
    public MonthlyJourney createChargeableJourney(String period, List<? extends TimedJourney> dailyJourneys) {
        final MonthlyJourney monthlyJourney = new MonthlyJourney();
        Optional<String> userId = dailyJourneys.stream().findAny().map(Journey::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        monthlyJourney.setUserId(userId.get());
        monthlyJourney.setMonthYear(period);
        monthlyJourney.addJourneys(dailyJourneys);
        return monthlyJourney;
    }
}
