package tm.creators;

import org.springframework.context.annotation.Configuration;
import tm.model.Journey;
import tm.model.TimedJourney;
import tm.model.Travel;

import java.util.List;
import java.util.Optional;

@Configuration
public class TravelCreator extends JourneyCreator<Travel> {
    public Travel createChargeableJourney(List<? extends Journey> journeys) {
        final Travel travel = new Travel();
        Optional<String> userId = journeys.stream().findAny().map(Journey::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        travel.setUserId(userId.get());
        travel.addJourneys(journeys);
        return travel;
    }
}
