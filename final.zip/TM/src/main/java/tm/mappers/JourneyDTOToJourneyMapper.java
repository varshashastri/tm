package tm.mappers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tm.dto.JourneyDTO;
import tm.model.SingleTripJourney;
import tm.model.StationZoneMap;
import tm.model.Zone;
import tm.model.ZoneChargeMap;

import java.util.*;

@Service
public class JourneyDTOToJourneyMapper {
    @Autowired
    private StationZoneMap stationZoneMap;

    @Autowired
    private ZoneChargeMap zoneChargeMap;

    public List<SingleTripJourney> toJourney(final @NonNull List<JourneyDTO> journeyDTOs) {
        final List<SingleTripJourney> journeys = new ArrayList<>();
        for (final JourneyDTO journeyDTO : journeyDTOs) {
            final SingleTripJourney singleTripJourney = createSingleTripJourney(journeyDTO);
            journeys.add(singleTripJourney);
        }
        return journeys;
    }

    private SingleTripJourney createSingleTripJourney(JourneyDTO journeyDTO) {
        return SingleTripJourney.builder()
                        .date(journeyDTO.getTime().toLocalDate())
                .userId(journeyDTO.getUserId())
                .zone(getZone(journeyDTO.getStation()))
                .direction(journeyDTO.getDirection())
                .build();
    }

    private Zone getZone(final @NonNull String stationName) {
        final Integer zoneNumber = stationZoneMap.getStationZoneMap().get(stationName);
        Float charge = zoneChargeMap.getZoneChargeMap().getOrDefault(zoneNumber, 0.10f);
        return Zone.builder().zoneNumber(zoneNumber).charge(charge).build();
    }

}
