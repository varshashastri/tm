package tm.groupers;

import lombok.NonNull;
import org.springframework.stereotype.Component;
import tm.model.Journey;
import tm.model.TimedJourney;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public abstract class TimedJourneyCreator<T> implements Creator<T> {
    public List<T> aggregateJourneys(List<? extends TimedJourney> journeys) {
        return journeys.stream().collect(Collectors.groupingBy(Journey::getUserId))
                .values()
                .stream()
                .map(this::groupByTimePeriod)
                .map(this::aggregate)
                .flatMap(List::stream)
                .toList();
    }
    protected Map<String, List<TimedJourney>> groupByTimePeriod(List<? extends TimedJourney> timedJourneys) {
        return timedJourneys.stream()
                .collect(Collectors.groupingBy(TimedJourney::getTimePeriod));
    }
    protected List<T> aggregate(final @NonNull Map<String, List<TimedJourney>> journeys) {
        return journeys.entrySet()
                .stream()
                .map(entry ->
                        createChargeableJourney(entry.getKey(), entry.getValue()))
                .toList();
    }

    public abstract T createChargeableJourney(final @NonNull String period, final @NonNull List<? extends TimedJourney> journeys);
}
