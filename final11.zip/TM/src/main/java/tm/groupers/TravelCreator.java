package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.Journey;
import tm.model.MonthlyJourney;
import tm.model.Travel;

import java.util.List;
import java.util.Optional;

@Component
public class TravelCreator extends JourneyCreator<Travel> {
    @Autowired
    private List<MonthlyJourney> monthlyJourneys;


    @Bean("travels")
    public List<Travel> provideJourneys() {
        return aggregateJourneys(monthlyJourneys);

    }
    public Travel createChargeableJourney(List<? extends Journey> journeys) {
        final Travel travel = new Travel();
        Optional<String> userId = journeys.stream().findAny().map(Journey::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        travel.setUserId(userId.get());
        travel.addJourneys(journeys);
        return travel;
    }
}
