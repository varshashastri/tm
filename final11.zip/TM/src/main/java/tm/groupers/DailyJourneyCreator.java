package tm.groupers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.DailyJourney;
import tm.model.Journey;
import tm.model.SingleTripJourney;
import tm.model.TimedJourney;

import java.util.List;
import java.util.Optional;

@Component
public class DailyJourneyCreator extends TimedJourneyCreator<DailyJourney> {
    @Autowired
    private List<SingleTripJourney> singleTripJourneys;


    @Bean("dailyJourneys")
    public List<DailyJourney> provideJourneys() {
        return aggregateJourneys(singleTripJourneys);
    }

    public DailyJourney createChargeableJourney(final @NonNull String period, final @NonNull List<? extends TimedJourney> journeys) {
        final DailyJourney dailyJourney = new DailyJourney();
        Optional<String> userId = journeys.stream().findAny().map(Journey::getUserId);
        if (userId.isEmpty()) {
            throw new RuntimeException();//create new exception or handle this properly.
        }
        dailyJourney.setUserId(userId.get());

        dailyJourney.addJourneys(journeys);
        dailyJourney.setDate(period);
        return dailyJourney;
    }


}
