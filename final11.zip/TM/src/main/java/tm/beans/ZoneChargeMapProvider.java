package tm.beans;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.dto.ZoneChargeDTO;
import tm.model.ZoneChargeMap;
import tm.util.FileToObjectMapper;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Configuration
public class ZoneChargeMapProvider {
    @Autowired
    private FileToObjectMapper fileToObjectMapper;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Bean
    public ZoneChargeMap zoneChargeMap() {
        try {
            final List<ZoneChargeDTO> zoneChargeDTOS = fileToObjectMapper.readZoneCharges();
            return new ZoneChargeMap(zoneChargeDTOS.stream().collect(Collectors.toMap(ZoneChargeDTO::getZone, ZoneChargeDTO::getCharge)));
        } catch (IOException e) {
            LOGGER.error("File not found" + e.getMessage());
            throw new RuntimeException(e);
        } catch (Exception e) {
            LOGGER.error("An unexpected error occurred: " + e.getMessage(), e);
            throw new RuntimeException("An unexpected error occurred", e);
        }
    }
}
