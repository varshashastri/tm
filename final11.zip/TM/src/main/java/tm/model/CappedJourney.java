package tm.model;

public interface CappedJourney extends Journey {
    float getCap();

    default float applyCap(float charges) {
        return Math.min(charges,getCap());
    }

}
