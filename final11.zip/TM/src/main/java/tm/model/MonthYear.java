package tm.model;

import lombok.Data;

import java.time.Month;

@Data
public class MonthYear {
    Month month;
    Integer year;

}
