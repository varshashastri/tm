package tm.groupers;

import lombok.NonNull;
import org.springframework.stereotype.Component;
import tm.dto.JourneyDTO;
import tm.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class FullTripJourneyGrouper extends TimedJourneyGrouper<FullTripJourney> {

    protected List<FullTripJourney> aggregate(final @NonNull Map<String, List<TimedJourney>> journeys) {
        return journeys
                .entrySet()
                .stream()
                .map(stringListEntry -> group(stringListEntry.getKey(), stringListEntry.getValue()))
                .flatMap(List::stream).collect(Collectors.toList());

    }

    private List<FullTripJourney> group(String date, List<TimedJourney> journeys){
        List<FullTripJourney> fullTripJourneys = new ArrayList<>();
        for (int i = 0; i < journeys.size(); ) {
            List<SingleTripJourney> singleTripJourneys = new ArrayList<>();
            if (((SingleTripJourney) journeys.get(i)).getDirection().equals("IN")) {
                singleTripJourneys.add((SingleTripJourney) journeys.get(i));
                i++;
            }
            if (i < journeys.size() && ((SingleTripJourney) journeys.get(i)).getDirection().equals("OUT")) {
                singleTripJourneys.add((SingleTripJourney) journeys.get(i));
                i++;
            }
            FullTripJourney fullTripJourney = this.creator.createChargeableJourney(date, singleTripJourneys);
            fullTripJourneys.add(fullTripJourney);
        }
        return fullTripJourneys;

    }
}
