package tm.groupers;

import org.springframework.stereotype.Component;
import tm.model.MonthlyJourney;
import tm.model.Travel;

@Component
public class MonthlyJourneyGrouper extends TimedJourneyGrouper<MonthlyJourney>{
}
