package tm.beans;

import java.util.List;

public interface ChargeableJourneyProvider<T> {
    List<T> provideJourneys();
}
