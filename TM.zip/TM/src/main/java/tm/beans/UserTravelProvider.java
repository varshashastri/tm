package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.JourneyGrouper;
import tm.model.*;

import java.util.List;

@Configuration
public class UserTravelProvider implements ChargeableJourneyProvider<Travel> {
    @Autowired
    private List<MonthlyJourney> monthlyJourneys;

    @Autowired
    private JourneyGrouper<Travel> userTravelGrouper;

    @Override
    @Bean("travels")
    public List<Travel> provideJourneys() {
        return userTravelGrouper.aggregateJourneys(monthlyJourneys);

    }
}
