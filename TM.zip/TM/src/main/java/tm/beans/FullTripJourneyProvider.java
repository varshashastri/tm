package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.TimedJourneyGrouper;
import tm.model.FullTripJourney;
import tm.model.SingleTripJourney;

import java.util.List;

@Configuration
public class FullTripJourneyProvider implements ChargeableJourneyProvider<FullTripJourney> {

    @Autowired
    private List<SingleTripJourney> singleTripJourneys;

    @Autowired
    private TimedJourneyGrouper<FullTripJourney> fullTripJourneyGrouper;

    @Bean("fullTripJourneys")
    @Override
    public List<FullTripJourney> provideJourneys() {
        return fullTripJourneyGrouper.aggregateJourneys(singleTripJourneys);//is this needed
    }
}

