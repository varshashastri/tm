package tm.creators;

import lombok.NonNull;
import org.springframework.stereotype.Component;
import tm.model.FullTripJourney;
import tm.model.Journey;
import tm.model.TimedJourney;

import java.util.List;
import java.util.Optional;

@Component
public class FullTripTimedJourneyCreator extends TimedJourneyCreator<FullTripJourney> {
    public FullTripJourney createChargeableJourney(final @NonNull String period, final @NonNull List<? extends TimedJourney> journeys) {
        final FullTripJourney fullTripJourney = new FullTripJourney();
        Optional<String> userId = journeys.stream().findAny().map(Journey::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        fullTripJourney.setUserId(userId.get());

        fullTripJourney.addJourneys(journeys);
        fullTripJourney.setDate(period);
        return fullTripJourney;

    }
}