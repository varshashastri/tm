package tm.model;

import lombok.Data;

@Data
public class FullTripJourney extends AggregatedJourney implements TimedJourney {

    String date;

    @Override
    public String getTimePeriod() {
        return date.toString();
    }

    @Override
    public Float calculateCharges() {
        float total = 2f;
        if (journeys.size() < 2) {
            total = 5f;
        }
        if (!journeys.isEmpty() && journeys.get(0) != null) {
            total += ((SingleTripJourney) journeys.get(0)).getZone().getCharge();
        }
        if (journeys.size() > 1 && journeys.get(1) != null) {
            total += ((SingleTripJourney) journeys.get(1)).getZone().getCharge();
        }
        return total;
    }
}
