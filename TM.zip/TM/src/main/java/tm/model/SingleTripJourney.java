package tm.model;

import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.sql.Time;
import java.time.LocalDate;

@Data
@SuperBuilder
public class SingleTripJourney extends UserJourney implements TimedJourney {
    public static final float BASIC_QUANTITY = 2f;
    public static final float FINE = 5f;
    private Zone zone;
    private LocalDate date;
    private String direction;//make it enum;

    @Override
    public String getTimePeriod() {
        return date.toString();
    }

    @Override
    public Float calculateCharges() {
        return zone.getCharge();
    }
}
