package tm.groupers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.AggregatedJourney;
import tm.model.DailyJourney;
import tm.model.SingleTripJourney;
import tm.model.TimedJourney;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

@Component
public class DailyJourneyCreator extends TimedJourneyCreator<DailyJourney, SingleTripJourney> {
    @Autowired
    private List<SingleTripJourney> singleTripJourneys;

    @Bean("dailyJourneys")
    public List<DailyJourney> getJourneys() {
        BiConsumer<DailyJourney, SingleTripJourney> biconsumer1 = AggregatedJourney::addJourney;
        BiConsumer<ArrayList<DailyJourney>, DailyJourney> con2 = ArrayList::add;
        return super.getJourneys(singleTripJourneys, biconsumer1, con2 );
    }

    @Override
    protected boolean isOfSameTimePeriod(SingleTripJourney big, DailyJourney small) {
        return big.getTimePeriod().equals(small.getTimePeriod()) && big.getUserId().equals(small.getUserId());
    }

    @Override
    public DailyJourney getObject(SingleTripJourney journey) {
        DailyJourney d = new DailyJourney();
        d.addJourney(journey);
        d.setUserId(journey.getUserId());
        d.setDate(journey.getTimePeriod());
        return d;
    }
}
