package tm.groupers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;

@Component
public abstract class TimedJourneyCreator<T, U> {

    protected abstract boolean isOfSameTimePeriod(U big, T small);

    public List<T> getJourneys(List<U> journeys,
                               BiConsumer<T, U> consumer,
                               BiConsumer<ArrayList<T>, T> con2) {
        return journeys.stream().collect(ArrayList::new,
                (ts, journey) -> {
                    ts.stream().filter(t -> isOfSameTimePeriod(journey, t)).findAny()
                            .ifPresentOrElse(t -> consumer.accept(t, journey),
                                    () -> con2.accept(ts, getObject(journey)));
                },
                ArrayList::addAll);
    }

    public abstract T getObject(U journey);
}
