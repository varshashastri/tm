package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.*;

import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;

@Component
public class TravelCreator extends TimedJourneyCreator<Travel, MonthlyJourney> {

    @Autowired
    private List<MonthlyJourney> monthlyJourneys;

    @Bean("travels")
    public List<Travel> getJourneys() {
        BiConsumer<Travel, MonthlyJourney> biconsumer1 = AggregatedJourney::addJourney;
        BiConsumer<ArrayList<Travel>, Travel> con2 = ArrayList::add;

        return super.getJourneys(monthlyJourneys, biconsumer1, con2);
    }

    @Override
    protected boolean isOfSameTimePeriod(MonthlyJourney monthlyJourney, Travel travel) {
        return travel.getUserId().equals(monthlyJourney.getUserId());
    }

    @Override
    public Travel getObject(MonthlyJourney monthlyJourney) {
        final Travel d = new Travel();
        d.addJourney(monthlyJourney);
        d.setUserId(monthlyJourney.getUserId());
        return d;
    }
}
