package tm.util;

import com.opencsv.bean.CsvToBeanBuilder;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;

public class CsvReader<T> {
    public List<T> readCsv(final String file, final Class<T> typeParameterClass) throws FileNotFoundException {
        return new CsvToBeanBuilder<T>(new FileReader(file))
                .withType(typeParameterClass)
                .build()
                .parse();
    }

}
