package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.DailyJourney;
import tm.model.SingleTripJourney;

import java.util.List;

@Component
public class DailyJourneyCreator implements TimedJourneyCreator<DailyJourney, SingleTripJourney> {
    @Autowired
    private List<SingleTripJourney> singleTripJourneys;

    @Bean("dailyJourneys")
    public List<DailyJourney> getJourneys() {
        return getJourneys(singleTripJourneys);
    }

    @Override
    public boolean shouldBeGrouped(SingleTripJourney small, DailyJourney big) {
        return small.getTimePeriod().equals(big.getTimePeriod()) && small.getUserId().equals(big.getUserId());
    }

    @Override
    public DailyJourney createNewAggregatedJourney(SingleTripJourney journey) {
        final DailyJourney d = new DailyJourney();
        d.addJourney(journey);
        d.setUserId(journey.getUserId());
        d.setDate(journey.getTimePeriod());
        return d;
    }
}
