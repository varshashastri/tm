package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.*;

import java.util.List;

@Component
public class TravelCreator implements TimedJourneyCreator<Travel, MonthlyJourney> {

    @Autowired
    private List<MonthlyJourney> monthlyJourneys;

    @Bean("travels")
    public List<Travel> getJourneys() {
        return getJourneys(monthlyJourneys);
    }

    @Override
    public boolean shouldBeGrouped(MonthlyJourney monthlyJourney, Travel travel) {
        return travel.getUserId().equals(monthlyJourney.getUserId());
    }

    @Override
    public Travel createNewAggregatedJourney(MonthlyJourney monthlyJourney) {
        final Travel d = new Travel();
        d.addJourney(monthlyJourney);
        d.setUserId(monthlyJourney.getUserId());
        return d;
    }
}
