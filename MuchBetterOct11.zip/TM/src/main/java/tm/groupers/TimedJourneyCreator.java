package tm.groupers;

import tm.model.AggregatedJourney;
import tm.model.Journey;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

public interface TimedJourneyCreator<T extends AggregatedJourney, U extends Journey> {

    boolean shouldBeGrouped(U journeyToGroup, T aggregatedJourney);

    default List<T> getJourneys(List<U> journeys) {
        return journeys.stream().collect(ArrayList::new,
                this::combineJourneyToBeGrouped,
                ArrayList::addAll);
    }

    private void combineJourneyToBeGrouped(ArrayList<T> aggregatedJourneys, U journeyToBeGrouped) {
        final BiConsumer<T, U> combineWithExistingAggregatedJourney = AggregatedJourney::addJourney;
        final BiConsumer<ArrayList<T>, T> addAsNewAggregatedJourney = ArrayList::add;

        aggregatedJourneys.stream()
                .filter(aggregatedJourney -> shouldBeGrouped(journeyToBeGrouped, aggregatedJourney))
                .findAny()
                .ifPresentOrElse(aggregatedJourney -> combineWithExistingAggregatedJourney.accept(aggregatedJourney, journeyToBeGrouped),
                        () -> addAsNewAggregatedJourney.accept(aggregatedJourneys, createNewAggregatedJourney(journeyToBeGrouped)));
    }

    T createNewAggregatedJourney(U journey);
}
