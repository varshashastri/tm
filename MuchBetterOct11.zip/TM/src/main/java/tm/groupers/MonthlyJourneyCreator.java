package tm.groupers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

@Component
public class MonthlyJourneyCreator implements TimedJourneyCreator<MonthlyJourney, DailyJourney> {
    @Autowired
    private List<DailyJourney> dailyJourneys;

    @Bean("monthlyJourneys")
    public List<MonthlyJourney> getJourneys() {
        return getJourneys(dailyJourneys);
    }


    @Override
    public boolean shouldBeGrouped(DailyJourney dailyJourney, MonthlyJourney monthlyJourney) {
        return monthlyJourney.getTimePeriod().equals(dailyJourney.getTimePeriod().substring(0, 7)) && monthlyJourney.getUserId().equals(dailyJourney.getUserId());
    }

    @Override
    public MonthlyJourney createNewAggregatedJourney(DailyJourney dailyJourney) {
        MonthlyJourney d = new MonthlyJourney();
        d.addJourney(dailyJourney);
        d.setUserId(dailyJourney.getUserId());
        d.setMonthYear(dailyJourney.getTimePeriod().substring(0, 7));
        return d;
    }
}
