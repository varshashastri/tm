package tm.model;

public interface Journey {

    Float calculateCharges();
    String getUserId();

}
