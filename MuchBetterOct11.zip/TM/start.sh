export VAR_ARG="--zoneMapFile=$1 --journeyFile=$2 --outputFile=$3"
make build