package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.TimedJourneyGrouper;
import tm.model.DailyJourney;
//import tm.model.FullTripJourney;
import tm.model.SingleTripJourney;

import java.util.List;

@Configuration
public class DailyJourneyProvider implements TimedJourneyProvider<DailyJourney> {

    @Autowired
    private List<SingleTripJourney> singleTripJourneys;

    @Autowired
    private TimedJourneyGrouper<DailyJourney> dailyJourneyGrouper;

    @Bean("dailyJourneys")
    @Override
    public List<DailyJourney> provideJourneys() {
        return dailyJourneyGrouper.aggregateJourneys(singleTripJourneys);
    }
}

