package tm.beans;

import java.util.List;

public interface TimedJourneyProvider<T> {
    List<T> provideJourneys();
}
