package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.dto.JourneyDTO;
import tm.mappers.JourneyDTOToJourneyMapper;
import tm.model.SingleTripJourney;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class JourneyProvider implements TimedJourneyProvider<SingleTripJourney> {
    @Autowired
    private JourneyDTOToJourneyMapper journeyDTOToJourneyMapper;
    @Autowired
    private List<JourneyDTO> journeyDTOs;

    @Bean("singleTripJourneys")
    public List<SingleTripJourney> provideJourneys() {
        return journeyDTOToJourneyMapper
                .toJourney(new ArrayList<>(journeyDTOs));
    }
}
