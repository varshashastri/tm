package tm.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Data
@SuperBuilder
@NoArgsConstructor
public class DailyJourney extends AggregatedJourney implements TimedJourney, CappedJourney {
    public static final float DAILY_CAP = 15f;
    private String date;

    public String getTimePeriod() {
        return date;
    }

    public float getCap() {
        return DAILY_CAP;
    }

    @Override
    public Float calculateCharges() {
        float total = 0f;
        for (int i = 0; i < journeys.size(); ) {
            Optional<SingleTripJourney> first = Optional.empty();
            Optional<SingleTripJourney> second = Optional.empty();
            if (((SingleTripJourney) journeys.get(i)).isEntry()) {
                first = Optional.of((SingleTripJourney) journeys.get(i));
                i++;
            }
            if (i < journeys.size() && !((SingleTripJourney) journeys.get(i)).isEntry()) {
                second = Optional.of((SingleTripJourney) journeys.get(i));
                i++;
            }
            total += calculateChargesForJourneyPair(new ImmutablePair<>(first, second));
        }
        return applyCap(total);
    }


    private float calculateChargesForJourneyPair(Pair<Optional<SingleTripJourney>, Optional<SingleTripJourney>> pairJourney) {
        if (pairJourney.getLeft().isEmpty() && pairJourney.getRight().isEmpty()) {
            throw new IllegalArgumentException();
        } else if (pairJourney.getLeft().isEmpty() || pairJourney.getRight().isEmpty()) {
            return 5f;
        } else {
            return 2f + pairJourney.getLeft().get().calculateCharges() + pairJourney.getRight().get().calculateCharges();
        }
    }

}
