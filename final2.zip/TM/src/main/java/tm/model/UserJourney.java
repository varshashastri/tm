package tm.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public abstract class UserJourney implements Journey {

    String userId;
    public String getUserId(){
        return userId;
    }
}
