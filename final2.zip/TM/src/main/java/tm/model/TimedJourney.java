package tm.model;

public interface TimedJourney extends Journey {
    String getTimePeriod();

}
