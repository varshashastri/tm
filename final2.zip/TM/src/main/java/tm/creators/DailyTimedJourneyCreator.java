package tm.creators;

import lombok.NonNull;
import org.springframework.stereotype.Component;
import tm.model.DailyJourney;
import tm.model.Journey;
import tm.model.TimedJourney;

import java.util.List;
import java.util.Optional;

@Component
public class DailyTimedJourneyCreator extends TimedJourneyCreator<DailyJourney> {
    public DailyJourney createChargeableJourney(final @NonNull String period, final @NonNull List<? extends TimedJourney> journeys) {
        final DailyJourney dailyJourney = new DailyJourney();
        Optional<String> userId = journeys.stream().findAny().map(Journey::getUserId);
        if (userId.isEmpty()) {
            throw new RuntimeException();//create new exception or handle this properly.
        }
        dailyJourney.setUserId(userId.get());

        dailyJourney.addJourneys(journeys);
        dailyJourney.setDate(period);
        return dailyJourney;
    }
}