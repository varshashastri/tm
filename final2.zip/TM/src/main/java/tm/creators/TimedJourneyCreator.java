package tm.creators;

import org.springframework.stereotype.Component;
import tm.model.Journey;
import tm.model.TimedJourney;

import java.util.List;

@Component
public abstract class TimedJourneyCreator<V>  {
    public abstract V createChargeableJourney(String period, List<? extends TimedJourney> grouperByPeriod);
}
