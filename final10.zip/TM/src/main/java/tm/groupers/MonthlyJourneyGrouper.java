package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.creators.TimedJourneyCreator;
import tm.model.DailyJourney;
import tm.model.MonthlyJourney;
import tm.model.SingleTripJourney;
import tm.model.Travel;

import java.util.List;

@Component
public class MonthlyJourneyGrouper extends TimedJourneyGrouper<MonthlyJourney>{
    @Autowired
    private List<DailyJourney> dailyJourneys;


    @Bean("monthlyJourney")
    public List<MonthlyJourney> provideJourneys() {
        return aggregateJourneys(dailyJourneys);
    }
}
