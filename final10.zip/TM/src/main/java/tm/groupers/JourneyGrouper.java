package tm.groupers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import tm.creators.JourneyCreator;
import tm.creators.TimedJourneyCreator;
import tm.model.Journey;
import tm.model.Travel;

import java.util.List;
import java.util.stream.Collectors;

@Component
public abstract class JourneyGrouper<T> {
    @Autowired
    protected JourneyCreator<T> creator;

    public abstract List<T> provideJourneys();
    public List<T> aggregateJourneys(List<? extends Journey> journeys) {
        return journeys.stream().collect(Collectors.groupingBy(Journey::getUserId))
                .values()
                .stream()
                .map(journeys1 -> creator.createChargeableJourney(journeys1))
                .toList();
    }
}
