package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.DailyJourney;
import tm.model.MonthlyJourney;
import tm.model.Travel;

import java.util.List;

@Component
public class TravelGrouper extends JourneyGrouper<Travel>{
    @Autowired
    private List<MonthlyJourney> monthlyJourneys;


    @Override
    @Bean("travels")
    public List<Travel> provideJourneys() {
        return aggregateJourneys(monthlyJourneys);

    }
}
