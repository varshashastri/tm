package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.ChargeableJourneyGrouper;
import tm.groupers.DailyJourneyGrouper;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;
import tm.model.Journey;
import tm.model.MonthlyJourney;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Configuration
public class DailyJourneyProvider implements ChargeableJourneyProvider<DailyJourney> {

    @Autowired
    private List<Journey> journeys;

    @Autowired
    private ChargeableJourneyGrouper<DailyJourney> dailyJourneyGrouper;

    @Bean("dailyJourneys")
    @Override
    public List<DailyJourney> provideJourneys() {
        return dailyJourneyGrouper.groupChargeableJourneys(journeys);//is this needed
    }
}

