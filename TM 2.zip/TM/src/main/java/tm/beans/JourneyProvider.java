package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.dto.JourneyDTO;
import tm.mappers.JourneyDTOToJourneyMapper;
import tm.model.ChargeableJourney;
import tm.model.Journey;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Configuration
public class JourneyProvider implements ChargeableJourneyProvider<Journey> {
    @Autowired
    private JourneyDTOToJourneyMapper journeyDTOToJourneyMapper;
    @Autowired
    private Map<String, List<JourneyDTO>> journeyDTOsPerUser;

    @Bean("journeys")
    public List<Journey> provideJourneys() {
        return journeyDTOToJourneyMapper
                .toJourney(journeyDTOsPerUser
                        .values()
                        .stream()
                        .flatMap(Collection::stream)
                        .collect(Collectors.toList()));
    }
}
