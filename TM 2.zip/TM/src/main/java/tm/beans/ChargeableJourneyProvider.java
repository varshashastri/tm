package tm.beans;

import tm.model.ChargeableJourney;

import java.util.List;
import java.util.Map;

public interface ChargeableJourneyProvider<T> {
    List<T> provideJourneys();
}
