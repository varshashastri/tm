package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.ChargeableJourneyGrouper;
import tm.groupers.MonthlyJourneyGrouper;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;
import tm.model.MonthlyJourney;

import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Configuration
public class MonthlyJourneyProvider implements ChargeableJourneyProvider<MonthlyJourney> {
    private final List<DailyJourney> dailyJourneys;

    private final ChargeableJourneyGrouper<MonthlyJourney> monthlyJourneyGrouper;

    @Autowired
    public MonthlyJourneyProvider(final List<DailyJourney> dailyJourneys, final MonthlyJourneyGrouper monthlyJourneyGrouper) {
        this.dailyJourneys = dailyJourneys;
        this.monthlyJourneyGrouper = monthlyJourneyGrouper;
    }

    @Bean("monthlyJourneys")
    public List<MonthlyJourney> provideJourneys() {
        return monthlyJourneyGrouper.groupChargeableJourneys(dailyJourneys);
    }

}
