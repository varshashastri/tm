package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.UserTravelGrouper;
import tm.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Configuration
public class UserTravelProvider implements ChargeableJourneyProvider<Travel> {
    @Autowired
    private List<MonthlyJourney> monthlyJourneys;

    @Autowired
    private UserTravelGrouper userTravelGrouper;

    @Override
    @Bean("travels")
    public List<Travel> provideJourneys() {
        return userTravelGrouper.groupChargeableJourneys(monthlyJourneys);

    }
}
