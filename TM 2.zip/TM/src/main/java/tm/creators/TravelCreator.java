package tm.creators;

import org.springframework.context.annotation.Configuration;
import tm.model.ChargeableJourney;
import tm.model.MonthlyJourney;
import tm.model.Travel;

import java.util.List;
import java.util.Optional;

@Configuration
public class TravelCreator implements ChargeableJourneyCreator<Travel> {
    public Travel createChargeableJourney(String period, List<? extends ChargeableJourney> monthlyJourneys) {
        final Travel travel = new Travel();
        Optional<String> userId = monthlyJourneys.stream().findAny().map(ChargeableJourney::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        travel.setUserId(userId.get());
        monthlyJourneys.forEach(travel::addJourney);
        return travel;
    }
}
