package tm.creators;

import org.springframework.context.annotation.Configuration;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;
import tm.model.MonthlyJourney;

import java.util.List;
import java.util.Optional;

@Configuration
public class MonthlyJourneyCreator implements ChargeableJourneyCreator<MonthlyJourney> {
    public MonthlyJourney createChargeableJourney(String period, List<? extends ChargeableJourney> dailyJourneys) {
        final MonthlyJourney monthlyJourney = new MonthlyJourney();
        Optional<String> userId = dailyJourneys.stream().findAny().map(ChargeableJourney::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        monthlyJourney.setUserId(userId.get());
        monthlyJourney.setMonthYear(period);
        dailyJourneys.forEach(monthlyJourney::addJourney);
        return monthlyJourney;
    }
}
