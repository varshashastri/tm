package tm.creators;

import tm.model.ChargeableJourney;
import tm.model.DailyJourney;
import tm.model.Journey;

import java.time.LocalDate;
import java.util.List;

public interface ChargeableJourneyCreator<V> {
    V createChargeableJourney(String period, List<? extends ChargeableJourney> groupedByDay);

}
