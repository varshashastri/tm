package tm.groupers;

import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import tm.creators.MonthlyJourneyCreator;
import tm.creators.TravelCreator;
import tm.model.ChargeableJourney;
import tm.model.MonthlyJourney;
import tm.model.Travel;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class UserTravelGrouper implements ChargeableJourneyGrouper<Travel>{

    @Autowired
    private TravelCreator travelCreator;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    public List<Travel> groupChargeableJourneys(final @NonNull List<? extends ChargeableJourney> chargeableJourneys) {
        return chargeableJourneys.stream().collect(Collectors.groupingBy(ChargeableJourney::getUserId))
                .values()
                .stream()
                .map(this::groupByDuration)
                .map(this::toUserTravels)
                .flatMap(List::stream)
                .toList();
    }

    private List<Travel> toUserTravels(final @NonNull Map<String, List<ChargeableJourney>> monthlyJourneys) {
        return monthlyJourneys.entrySet()
                .stream()
                .map(entry ->
                        travelCreator.createChargeableJourney(entry.getKey(), entry.getValue()))
                .toList();
    }
}
