package tm.groupers;

import tm.model.ChargeableJourney;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public interface ChargeableJourneyGrouper<T> {
    List<T> groupChargeableJourneys(List<? extends ChargeableJourney> groupableJourneys);
    default Map<String, List<ChargeableJourney>> groupByDuration(List<? extends ChargeableJourney> chargeableJourneys) {
        return chargeableJourneys.stream()
                .collect(Collectors.groupingBy(ChargeableJourney::getDuration));
    }

}
