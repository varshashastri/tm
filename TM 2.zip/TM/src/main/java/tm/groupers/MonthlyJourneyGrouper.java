package tm.groupers;

import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import tm.creators.MonthlyJourneyCreator;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;
import tm.model.MonthlyJourney;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class MonthlyJourneyGrouper implements ChargeableJourneyGrouper<MonthlyJourney>{

    @Autowired
    private MonthlyJourneyCreator monthlyJourneyCreator;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    public List<MonthlyJourney> groupChargeableJourneys(final @NonNull List<? extends ChargeableJourney> chargeableJourneys) {
        return chargeableJourneys.stream().collect(Collectors.groupingBy(ChargeableJourney::getUserId))
                .values()
                .stream()
                .map(this::groupByDuration)
                .map(this::toMonthlyJourneys)
                .flatMap(List::stream)
                .toList();
    }

    private List<MonthlyJourney> toMonthlyJourneys(final @NonNull Map<String, List<ChargeableJourney>> groupedByMonth) {
        return groupedByMonth.entrySet()
                .stream()
                .map(entry ->
                        monthlyJourneyCreator.createChargeableJourney(entry.getKey(), entry.getValue()))
                .toList();
    }
}
