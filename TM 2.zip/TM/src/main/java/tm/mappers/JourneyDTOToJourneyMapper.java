package tm.mappers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tm.dto.JourneyDTO;
import tm.model.Journey;
import tm.model.StationZoneMap;
import tm.model.Zone;
import tm.model.ZoneChargeMap;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class JourneyDTOToJourneyMapper {
    private static final String OUT = "OUT";
    private static final String IN = "IN";
    @Autowired
    private StationZoneMap stationZoneMap;

    @Autowired
    private ZoneChargeMap zoneChargeMap;

    public List<Journey> toJourney(final @NonNull List<JourneyDTO> journeyDTOs) {
        final List<Journey> journeys = new ArrayList<>();
        for (int i = 0; i < journeyDTOs.size(); ) {
            Journey journey = new Journey();

            if (journeyDTOs.get(i).getDirection().equals(IN)) {
                final Zone zone = getZone(journeyDTOs.get(i).getStation());
                journey.setFromZone(zone);
                journey.setDate(journeyDTOs.get(i).getTime().toLocalDate());
                journey.setUserId(journeyDTOs.get(i).getUserId());
                i++;
            }
            if (i < journeyDTOs.size()
                    && journeyDTOs.get(i).getDirection().equals(OUT)
                    && (journey.getDate() == null
                    || (journey.getDate().equals(journeyDTOs.get(i-1).getTime().toLocalDate())))) {
                final Zone zone = getZone(journeyDTOs.get(i).getStation());
                journey.setDate(journeyDTOs.get(i).getTime().toLocalDate());
                journey.setUserId(journeyDTOs.get(i).getUserId());
                journey.setToZone(zone);

                i++;
            }
            journeys.add(journey);
        }
        return journeys;
    }

    private Zone getZone(final @NonNull String stationName) {
        final Integer zoneNumber = stationZoneMap.getStationZoneMap().get(stationName);
        Float charge = zoneChargeMap.getZoneChargeMap().getOrDefault(zoneNumber, 0.10f);
        return Zone.builder()
                .zoneNumber(zoneNumber)
                .charge(charge)
                .build();
    }

}
