package tm.dto;

import com.opencsv.bean.CsvBindByName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ZoneChargeDTO {
    @CsvBindByName(column = "zone", required = true)
    private int zone;
    @CsvBindByName(column = "charge", required = true)
    private float charge;
}
