package tm.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JourneyDTO {
    @CsvBindByName(column = "user_id", required = true)
    private String userId;
    @CsvBindByName(column = "station", required = true)
    private String station;
    @CsvBindByName(column = "direction", required = true)
    private String direction;
    @CsvDate(value = "yyyy-MM-dd\'T\'H:mm:ss")
    @CsvBindByName(column = "time", required = true)
    private LocalDateTime time;

}
