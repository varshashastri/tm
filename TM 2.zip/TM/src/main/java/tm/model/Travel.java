package tm.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
public class Travel extends ChargeableJourney {

    @Override
    public String getDuration() {
        return "";
    }

    @Override
    public float getCap() {
        return Float.MAX_VALUE;
    }
}
