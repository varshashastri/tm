//package tm.model;
//
//import lombok.Builder;
//import lombok.Data;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@Data
//@Builder
//public class User {
//    private String userId;
//    private Travel travel;
//
//    public float calculateCharges() {
//        return travel.calculateCharges();
//    }
//}
