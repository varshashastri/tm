package tm.model;

import lombok.Data;

import java.time.LocalDate;

@Data
public class Journey extends ChargeableJourney {
    public static final float BASIC_QUANTITY = 2f;
    public static final float FINE = 5f;
    private Zone fromZone;
    private Zone toZone;
    private LocalDate date;

    @Override
    public String getDuration() {
        return date.toString();
    }

    public float getCap() {
        return Float.MAX_VALUE;//make it constant
    }
    public Float calculateCharges() {
        float total = BASIC_QUANTITY;
        if (fromZone == null && toZone == null) {
            return 0f;
        }
        if (fromZone != null) {
            total += fromZone.getCharge();
        }
        if (toZone != null) {
            total += toZone.getCharge();
        }
        if (fromZone == null || toZone == null) {
            total += FINE;
        }
        return total;
    }
}
