//package tm.application;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import tm.model.User;
//
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//
//@Component
//public class UserChargesCalculator {
//
//    @Autowired
//    private List<User> users;
//
//    public Map<String, Float> calculateUserCharges() {
//        return users.stream()
//                .collect(Collectors.toMap(User::getUserId, User::calculateCharges));
//    }
//}
