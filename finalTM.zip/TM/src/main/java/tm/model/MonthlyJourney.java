package tm.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
public class MonthlyJourney extends AggregatedJourney implements TimedJourney, CappedJourney {

    public static final float MONTHLY_CAP = 100f;
    private String monthYear;

    @Override
    public String getTimePeriod() {
        return monthYear;
    }

    @Override
    public float getCap() {
        return MONTHLY_CAP;//make it constant
    }
    @Override
    public Float calculateCharges() {
        return applyCap(super.calculateCharges());
    }
}
