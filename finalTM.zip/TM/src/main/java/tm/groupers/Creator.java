package tm.groupers;

import java.util.List;

public interface Creator<T> {
    List<T> getJourneys();

}
