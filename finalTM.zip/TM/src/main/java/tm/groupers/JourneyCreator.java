package tm.groupers;

import lombok.NonNull;
import org.springframework.stereotype.Component;
import tm.model.Journey;

import java.util.List;
import java.util.stream.Collectors;

@Component
public abstract class JourneyCreator<T> implements Creator<T> {

    public List<T> aggregateJourneys(List<? extends Journey> journeys) {
        return journeys.stream().collect(Collectors.groupingBy(Journey::getUserId))
                .values()
                .stream()
                .map(this::createChargeableJourney)
                .toList();
    }

    public abstract T createChargeableJourney(List<? extends Journey> journeys);

}
