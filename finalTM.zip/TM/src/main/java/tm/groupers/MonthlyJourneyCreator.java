package tm.groupers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.*;

import java.util.List;
import java.util.Optional;

@Component
public class MonthlyJourneyCreator extends TimedJourneyCreator<MonthlyJourney> {
    @Autowired
    private List<DailyJourney> dailyJourneys;


    @Bean("monthlyJourney")
    public List<MonthlyJourney> getJourneys() {
        return aggregateJourneys(dailyJourneys);
    }

    public MonthlyJourney createChargeableJourney(final @NonNull String period, List<? extends TimedJourney> dailyJourneys) {
        final MonthlyJourney monthlyJourney = new MonthlyJourney();
        Optional<String> userId = dailyJourneys.stream().findAny().map(Journey::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        monthlyJourney.setUserId(userId.get());
        monthlyJourney.setMonthYear(period);
        monthlyJourney.addJourneys(dailyJourneys);
        return monthlyJourney;
    }
}
