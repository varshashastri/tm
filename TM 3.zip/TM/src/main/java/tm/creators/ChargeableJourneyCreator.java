package tm.creators;

import tm.model.ChargeableJourney;

import java.util.List;

public interface ChargeableJourneyCreator<V> {
    V createChargeableJourney(String period, List<? extends ChargeableJourney> grouperByPeriod);

}
