package tm.creators;

import lombok.NonNull;
import org.springframework.stereotype.Component;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;
import tm.model.FullTripJourney;

import java.util.List;
import java.util.Optional;

@Component
public class FullTripJourneyCreator implements ChargeableJourneyCreator<FullTripJourney> {
    public FullTripJourney createChargeableJourney(final @NonNull String period, final @NonNull List<? extends ChargeableJourney> journeys) {
        final FullTripJourney fullTripJourney = new FullTripJourney();
        Optional<String> userId = journeys.stream().findAny().map(ChargeableJourney::getUserId);
        if(userId.isEmpty()){
            throw new RuntimeException();//create new exception or handle this properly.
        }
        fullTripJourney.setUserId(userId.get());

        journeys.forEach(fullTripJourney::addJourney);
        fullTripJourney.setDate(period);
        return fullTripJourney;

    }
}