package tm.creators;

import lombok.NonNull;
import org.springframework.stereotype.Component;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;

import java.util.List;
import java.util.Optional;

@Component
public class DailyJourneyCreator implements ChargeableJourneyCreator<DailyJourney> {
    public DailyJourney createChargeableJourney(final @NonNull String period, final @NonNull List<? extends ChargeableJourney> journeys) {
        final DailyJourney dailyJourney = new DailyJourney();
        Optional<String> userId = journeys.stream().findAny().map(ChargeableJourney::getUserId);
        if (userId.isEmpty()) {
            throw new RuntimeException();//create new exception or handle this properly.
        }
        dailyJourney.setUserId(userId.get());

        journeys.forEach(dailyJourney::addJourney);
        dailyJourney.setDate(period);
        return dailyJourney;
    }
}