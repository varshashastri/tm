package tm.groupers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.DailyJourney;
import tm.model.FullTripJourney;
import tm.model.MonthlyJourney;

import java.time.Month;
import java.util.List;

@Component
public class MonthlyJourneyGrouper extends ChargeableJourneyGrouper<MonthlyJourney>{

}
