package tm.groupers;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.creators.ChargeableJourneyCreator;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public abstract class ChargeableJourneyGrouper<T> {
    @Autowired
    protected ChargeableJourneyCreator<T> creator;

    public List<T> chargeableJourneys(List<? extends ChargeableJourney> chargeableJourneys) {
        return chargeableJourneys.stream().collect(Collectors.groupingBy(ChargeableJourney::getUserId))
                .values()
                .stream()
                .map(this::groupByDuration)
                .map(this::groupTo)
                .flatMap(List::stream)
                .toList();
    }
    protected Map<String, List<ChargeableJourney>> groupByDuration(List<? extends ChargeableJourney> chargeableJourneys) {
        return chargeableJourneys.stream()
                .collect(Collectors.groupingBy(ChargeableJourney::getTimePeriod));
    }
    protected List<T> groupTo(final @NonNull Map<String, List<ChargeableJourney>> journeys) {
        return journeys.entrySet()
                .stream()
                .map(entry ->
                        creator.createChargeableJourney(entry.getKey(), entry.getValue()))
                .toList();
    }
}
