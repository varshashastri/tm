package tm.groupers;

import lombok.NonNull;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tm.model.ChargeableJourney;
import tm.model.DailyJourney;
import tm.model.FullTripJourney;
import tm.model.SingleTripJourney;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class FullTripJourneyGrouper extends ChargeableJourneyGrouper<FullTripJourney> {

    @Override
    protected List<FullTripJourney> groupTo(final @NonNull Map<String, List<ChargeableJourney>> journeys) {
        return journeys
                .entrySet()
                .stream()
                .map(stringListEntry -> group(stringListEntry.getKey(), stringListEntry.getValue()))
                .flatMap(List::stream).collect(Collectors.toList());

    }

    private List<FullTripJourney> group(String date, List<ChargeableJourney> journeys){
        List<FullTripJourney> fullTripJourneys = new ArrayList<>();
        for (int i = 0; i < journeys.size(); ) {
            List<SingleTripJourney> singleTripJourneys = new ArrayList<>();
            if (((SingleTripJourney) journeys.get(i)).getDirection().equals("IN")) {
                singleTripJourneys.add((SingleTripJourney) journeys.get(i));
                i++;
            }
            if (i < journeys.size() && ((SingleTripJourney) journeys.get(i)).getDirection().equals("OUT")) {
                singleTripJourneys.add((SingleTripJourney) journeys.get(i));
                i++;
            }
            FullTripJourney fullTripJourney = this.creator.createChargeableJourney(date, singleTripJourneys);
            fullTripJourneys.add(fullTripJourney);
        }
        return fullTripJourneys;

    }
}
