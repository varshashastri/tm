package tm.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DailyJourney extends ChargeableJourney {
    public static final float DAILY_CAP = 15f;
    private String date;

    public String getTimePeriod() {
        return date;
    }

    public float getCap() {
        return DAILY_CAP;
    }
}
