package tm.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MonthlyJourney extends ChargeableJourney {

    public static final float MONTHLY_CAP = 100f;
    private String monthYear;

    @Override
    public String getTimePeriod() {
        return monthYear;
    }

    public float getCap() {
        return MONTHLY_CAP;//make it constant
    }
}
