package tm.model;

import lombok.Data;

import java.time.LocalDate;

@Data
public class FullTripJourney extends ChargeableJourney {

    String date;

    @Override
    public String getTimePeriod() {
        return date.toString();
    }

    @Override
    public float getCap() {
        return Float.MAX_VALUE;
    }

    @Override
    public Float calculateCharges() {
        float total = 2f;
        if (chargableJourneys.size() < 2) {
            total = 5f;
        }
        if (!chargableJourneys.isEmpty() && chargableJourneys.get(0) != null) {
            total += ((SingleTripJourney) chargableJourneys.get(0)).getZone().getCharge();
        }
        if (chargableJourneys.size() > 1 && chargableJourneys.get(1) != null) {
            total += ((SingleTripJourney) chargableJourneys.get(1)).getZone().getCharge();
        }
        return total;
    }
}
