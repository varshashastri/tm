package tm.model;


import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

@Data
@SuperBuilder
public abstract class ChargeableJourney {
     String userId;//may be user class.
     List<ChargeableJourney> chargableJourneys = new ArrayList<>();

     public ChargeableJourney(){}
     public abstract String getTimePeriod();

     public abstract float getCap();
     public void addJourney(ChargeableJourney journey) {
          chargableJourneys.add(journey);
     }
     public Float calculateCharges() {
          return chargableJourneys.stream()
                  .map(ChargeableJourney::calculateCharges)
                  .reduce(Float::sum)
                  .map(sum -> Math.min(getCap(), sum))
                  .orElse(0f);
     }
}
