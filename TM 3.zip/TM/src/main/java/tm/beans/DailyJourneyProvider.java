package tm.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tm.groupers.ChargeableJourneyGrouper;
import tm.model.DailyJourney;
import tm.model.FullTripJourney;
import tm.model.SingleTripJourney;

import java.util.List;

@Configuration
public class DailyJourneyProvider implements ChargeableJourneyProvider<DailyJourney> {

    @Autowired
    private List<FullTripJourney> fullTripJourneys;

    @Autowired
    private ChargeableJourneyGrouper<DailyJourney> dailyJourneyGrouper;

    @Bean("dailyJourneys")
    @Override
    public List<DailyJourney> provideJourneys() {
        return dailyJourneyGrouper.chargeableJourneys(fullTripJourneys);//is this needed
    }
}

