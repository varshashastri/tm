package tm.exceptions;

public class IncorrectFileConfigurationException extends Exception{
    public IncorrectFileConfigurationException(String message){
        super(message);
    }
}
