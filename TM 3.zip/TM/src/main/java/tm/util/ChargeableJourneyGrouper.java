//package tm.util;
//
//import lombok.NonNull;
//import org.springframework.stereotype.Component;
//import tm.model.ChargeableJourney;
//import tm.model.DailyJourney;
//import tm.model.MonthlyJourney;
//
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//
//@Component
//public class ChargeableJourneyGrouper {
//    public Map<String, List<ChargeableJourney>> groupJourneys(final @NonNull List<ChargeableJourney> chargeableJourneys) {
//        return chargeableJourneys.stream()
//                .collect(Collectors.groupingBy(ChargeableJourney::getDuration));
//    }
//
//
//}
