package tm.util;
import com.opencsv.CSVWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import tm.dto.JourneyDTO;
import tm.dto.ZoneChargeDTO;
import tm.dto.ZoneMapDTO;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class FileToObjectMapper {
    @Value("${outputFile}")
    private String outputFile;
    @Value("${zoneMapFile}")
    private String zoneMapFile;
    @Value("${journeyFile}")
    private String journeyFile;
    @Value("${zoneChargeFile}")
    private String zoneChargeFile;

    public List<ZoneMapDTO> readZoneMaps() throws FileNotFoundException {
        final CsvReader<ZoneMapDTO> zoneMapCsvReader = new CsvReader<>();
        return zoneMapCsvReader.readCsv(zoneMapFile, ZoneMapDTO.class);
    }

    public List<JourneyDTO> readJourneys() throws FileNotFoundException {
        final CsvReader<JourneyDTO> journeyCsvReader = new CsvReader<>();
        return journeyCsvReader.readCsv(journeyFile, JourneyDTO.class);
    }
    public List<ZoneChargeDTO> readZoneCharges() throws FileNotFoundException {
        final CsvReader<ZoneChargeDTO> zoneChargeCsvReader = new CsvReader<>();
        return zoneChargeCsvReader.readCsv(zoneChargeFile, ZoneChargeDTO.class);
    }
    public Map<String, Float> getStationChargeMap() throws FileNotFoundException {
        final List<ZoneMapDTO> zoneMapDTOList = readZoneMaps();
        final List<ZoneChargeDTO> zoneChargeDTOList = readZoneCharges();
        final Map<String, Float> stationChargeMap = new HashMap<>();
        for (ZoneMapDTO zoneMapDTO : zoneMapDTOList) {
            for (ZoneChargeDTO zoneChargeDTO : zoneChargeDTOList) {
                if (zoneMapDTO.getZone() == zoneChargeDTO.getZone()) {
                    stationChargeMap.put(zoneMapDTO.getStation(), zoneChargeDTO.getCharge());
                }
            }
        }
        return stationChargeMap;
    }


    public void writeToOutputFile(final Map<String, Float> result) throws IOException {
        final String[] users = result.keySet().toArray(new String[]{});
        Arrays.sort(users);
        final List<String[]> userChargeList = new ArrayList<>();
        for (String user : users) {
            String[] userCharge = new String[]{user, String.valueOf(result.get(user))};
            userChargeList.add(userCharge);
        }
        try (CSVWriter writer = new CSVWriter(new FileWriter(outputFile))) {
            writer.writeAll(userChargeList);
        }
    }
}
