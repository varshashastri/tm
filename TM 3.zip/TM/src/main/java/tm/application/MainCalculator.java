package tm.application;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tm.model.ChargeableJourney;
import tm.model.Travel;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@SpringBootApplication(scanBasePackages = "tm.*")
@Slf4j
public class MainCalculator implements CommandLineRunner {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private List<Travel> chargeableJourneys;
    public static void main(String[] args) {
        SpringApplication.run(MainCalculator.class, args);

    }

    @Override
    public void run(String... args) {
        try {
            final Map<String, Float> userCharges = chargeableJourneys
                    .stream()
                    .collect(Collectors.toMap(ChargeableJourney::getUserId, ChargeableJourney::calculateCharges, Float::sum));

//            final Map<String, Float> userCharges = travels.getChargableJourneys()
//                    .stream()
//                    .collect(Collectors.toMap(ChargeableJourney::getUserId,
//                            ChargeableJourney::calculateCharges));
//            userCharges.forEach((key, value) -> System.out.println(key + ":" + value));
            userCharges.forEach((key, value) -> System.out.println(key + ":" + value));
        } catch (Exception e) {
            logger.error("An error occurred during calculation: {}", e.getMessage());
        }
    }
}